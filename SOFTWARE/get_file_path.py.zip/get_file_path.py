#!/usr/bin/env python
# coding: utf-8

# In[ ]:


def get_file():
    file_path = input("Enter the CSV file path: ")
    return file_path

